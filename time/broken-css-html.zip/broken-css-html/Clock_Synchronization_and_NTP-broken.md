



###  TimeLines, OffSets and Clock Synchronization<a name="Segals_Law"></a>



If we have a single Watch, can we can be reasonably sure of what the time is?

<PRE style="font-size: 75%">
                   __________ 
                  /          \
                  |          |
                  |          |
                  |          |
                 _|__________|
               _/_____________\_
              / ______________  \
             | |  _     _  _  | |)
             | | | | o  _|| | | |
             | | |_| o |_ |_| | |
             | |______________| |)
              \_________________/
                \______________/
                  |          |
                  |          |
                  |          |
                  |     0    |
                  |          |
                  \__________/


  Watch    |----|----|----|----*----|----|
Time Line  0    5    10   15   20   25   30

</PRE>

There are number of problems with using a single Watch to determine the time, such as...

1. How can we can confirm that the Watch is displaying the correct time. 
    * The Watch could be correct, it could be behind the correct time, it could ahead of the correct time.
    * The Watch could be running too fast or too slow.
    * The Watch could be drifting, sometimes running too fast, and/or too slow.







Problem (1) Solution (a)...

* We can purchase a 2nd Watch.
* We can now compare the time on Watch A and Watch B.
    * If they are different, we can approximate the time by averaging the times on both of the watches.
    * If the time between the 2 watches differs, how can we determine if there is a problem with either watch or both watches?


> "A man with a watch knows what time it is. A man with two watches is never sure."
                                                                           Segal's Law 

<PRE style="font-size: 75%">

      __________               __________
     /          \             /          \
     +          +             +          +
     |          |             |          |
     |          |             |          |
    _+__________+            _+__________+
  _/_____________\_        _/_____________\_
 / ______________  \      / ______________  \
| |  _     _  _  | |)    | |  _     _  _  | |)
| | | | o | || | | |     | | | | o | || | | |
| | |_| o |_||_| | |     | | |_| o |_||_| | |
| |______________| |)    | |______________| |) 
 \_________________/      \_________________/
   \______________/         \______________/
     +          +             +          +
     |          |             |          |
     |          |             |          |
     |     A    |             |     B    |
     +          +             +          +
     \__________/             \__________/

</PRE>


<style>
  #ascii-art-timeline-B-insync-with-A{
    font-family: monospace;
    white-space: pre;
    font-size: 75%;
  }
</style>

<div id="ascii-art-timeline-B-insync-with-A">


<script>

 (function () { //Start of function wrapper to isolate from other ascii art
const frames = [
 
  `
Watch A      0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .              .              .
             .              .              .
             .              .              .   
Watch B      |----|----|----|----|----|----|
Time Line    0    5    10   15   20   25   30
 
 `
];

let currentFrameIndex = 0;
const asciiArtElementTimeLine = document.getElementById("ascii-art-timeline-B-infront-of-A");

function renderFrame() {
  asciiArtElementTimeLine.textContent = frames[currentFrameIndex];
  currentFrameIndex = (currentFrameIndex + 1) % frames.length;
}

// Initial render
renderFrame();

// Start animation at 2 frames per second (500ms delay)
setInterval(renderFrame, 500);

 }()); //End of function wrapper to isolate from other ascii art


</script>


</div>

With just 2 Watches it is impossible to determine if the time is correct on either of the Watches.


Side Note...
     Describe atomic visibility, you can only view one of the timelines in a single action,
     Therefore to view both time lines you need to perform 2 actions.


---------------------------------------------------------------------------------

###  Examples of Clock Skew and Drift<a name="Clock_drift"></a>



#### Watch B is running too fast

Watch B is running FASTER than Watch A


<style>
  #ascii-art-timeline-B-faster-than-A {
    font-family: monospace;
    white-space: pre;
    font-size: 75%;
  }
</style>

<div id="ascii-art-timeline-B-faster-than-A">


<script>

 (function () { //Start of function wrapper to isolate from other ascii art
const frames = [
 
  `
Watch A      0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .              .              .
             .            .             .
             .           .           .  
 `
];

let currentFrameIndex = 0;
const asciiArtElementTimeLine = document.getElementById("ascii-art-timeline-B-faster-than-A");

function renderFrame() {
  asciiArtElementTimeLine.textContent = frames[currentFrameIndex];
  currentFrameIndex = (currentFrameIndex + 1) % frames.length;
}

// Initial render
renderFrame();

// Start animation at 2 frames per second (500ms delay)
setInterval(renderFrame, 500);

 }()); //End of function wrapper to isolate from other ascii art


</script>


</div>



#### Watch B is running too slow

Watch B is running SLOWER than Watch A

<style>
  #ascii-art-timeline-B-Slower-than-A {
    font-family: monospace;
    white-space: pre;
    font-size: 75%;
  }
</style>

<div id="ascii-art-timeline-B-Slower-than-A">


<script>

 (function () { //Start of function wrapper to isolate from other ascii art
const frames = [

  `
Watch A      0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .              .              .
             .            .             .
             .           .           . 
Watch B      |------|------|------|------|------|~
Time Line    0      5      10     15     20     25
 
 `
];

let currentFrameIndex = 0;
const asciiArtElementTimeLine = document.getElementById("ascii-art-timeline-B-Slower-than-A");

function renderFrame() {
  asciiArtElementTimeLine.textContent = frames[currentFrameIndex];
  currentFrameIndex = (currentFrameIndex + 1) % frames.length;
}

// Initial render
renderFrame();

// Start animation at 2 frames per second (500ms delay)
setInterval(renderFrame, 500);

 }()); //End of function wrapper to isolate from other ascii art


</script>


</div>

#### Watch B is unstable, sometimes running too fast and sometimes running too slow

* list asdf
* list

Watch B initially in sync with Watch A
Watch B running SLOWER than Watch A (out of sync)
Watch B running FASTER than Watch A (out of sync)
Watch A in sync with Watch B


<div id="ascii-art-timeline-B-unstable">

<style>
  #ascii-art-timeline-B-unstable {
    font-family: monospace;
    white-space: pre;
    font-size: 75%;
  }
</style>

<script>

 (function () { //Start of function wrapper to isolate from other ascii art
const frames = [
 
  `
1
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .         .         .         .
             .         .         .         .
             .         .         .         .
 Watch B     |----|----|----|----|----|----|
Time Line    0    5    10   15   20   25   30
  `,
  `
2
 Watch A     0    5    10   15   20   25   30
Time Line    *----|----|----|----|----|----|
             .         .         .         .
             .         .         .         .
             .         .         .         .
 Watch B     *----|----|----|----|----|----|
Time Line    0    5    10   15   20   25   30
  `,
  `
3
 Watch A     0    5    10   15   20   25   30
Time Line    |-*--|----|----|----|----|----|
             .         .         .         .
             .         .         .         .
             .         .         .         .
 Watch B     |-*---|---|----|----|----|----|
Time Line    0     5   10   15   20   25   30
  `,
  `
4
 Watch A     0    5    10   15   20   25   30
Time Line    |---*|----|----|----|----|----|
             .         .         .         .
             .         .         .         .
             .         .         .         .
 Watch B     |---*--|--|----|----|----|----|
Time Line    0      5  10   15   20   25   30
  `,
  `
5
 Watch A     0    5    10   15   20   25   30
Time Line    |----|*---|----|----|----|----|
             .         .         .         .
             .         .         .         .
             .         .         .         .
 Watch B     |-----*-|-|----|----|----|----|
Time Line    0       5 10   15   20   25   30
  `,
  `
6
 Watch A     0    5    10   15   20   25   30
Time Line    |----|---*|----|----|----|----|
             .         .         .         .
             .          .        .         .
             .          .        .         .
 Watch B     |-------|*-|---|----|----|----|
Time Line    0       5  10  15   20   25   30
  `,
  `
7
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|-*--|----|----|----|
             .         .         .         .
             .          .        .         .
             .           .       .         .
 Watch B     |-------|---*---|---|----|----|
Time Line    0       5   10  15  20   25   30
  `,
  `
8
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----*----|----|----|
             .         .         .         .
             .           .        .        .
             .            .       .        .
 Watch B     |-------|----|-*-|---|----|---|
Time Line    0       5    10  15  20   25  30
  `,
  `
9
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|--*-|----|----|
             .         .         .         .
             .           .        .        .
             .            .       .        .
 Watch B     |-------|----|---|*--|----|---|
Time Line    0       5    10  15  20   25  30
  `,
  `
10
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|*---|----|
             .         .         .         .
             .           .         .       .
             .    Slow     .       .       .
 Watch B     |-------|-----|---|--*|---|---|
Time Line    0       5     10  15  20  25  30
  `,
  `
11
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|---*|----|
             .         .         .         .
             .           .         .       .
             .    Slow     .       .       .
 Watch B     |-------|-----|---|---|-*-|---|
Time Line    0       5     10  15  20  25  30
  `,
  `
12
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|*---|
             .         .         .         .
             .           .  Same   .       .
             .    Slow     . Rate    .     .
 Watch B     |-------|-----|----|----|-*|--|
Time Line    0       5     10   15   20 25 30
  `,
  `
13
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|---*|
             .         .         .         .
             .           .   Same .       .
             .    Slow     .  Rate    .Fast.
 Watch B     |-------|-----|----|----|--|-*|
Time Line    0       5     10   15   20 25 30
  `,
  `
14
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----*
             .         .         .         .
             .           .   Same  .       .
             .    Slow     .  Rate    .Fast.
 Watch B     |-------|-----|----|----|--|--*
Time Line    0       5     10   15   20 25 30
  `,
  `
15
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .         .         .         .
             .           .   Same  .       .
             .    Slow     .  Rate    .Fast.
 Watch B     |-------|-----|----|----|--|--|
Time Line    0       5     10   15   20 25 30
  `,
  `
16
 Watch A     0    5    10   15   20   25   30
Time Line    |----|----|----|----|----|----|
             .         .         .         .
             .           .   Same  .       .
             .    Slow     .  Rate    .Fast.
 Watch B     |-------|-----|----|----|--|--|
Time Line    0       5     10   15   20 25 30
  `
];

let currentFrameIndex = 0;
const asciiArtElementTimeLine = document.getElementById("ascii-art-timeline-B-unstable");

function renderFrame() {
  asciiArtElementTimeLine.textContent = frames[currentFrameIndex];
  currentFrameIndex = (currentFrameIndex + 1) % frames.length;
}

// Initial render
renderFrame();

// Start animation at 2 frames per second (500ms delay)
setInterval(renderFrame, 500);

 }()); //End of function wrapper to isolate from other ascii art



</script>

</div>



* list
* list

Problem (1) (2) and (3) Solution (b)...

- We can gain access to an accurate time source.
- We can synchronise the Watch A to the accurate time source.
- We can repeatedly compare the time displayed by the Watch A with the accurate time source.
- If the Watch A repeatedly shows the same time as the accurate time source,
    - then the accuracy and reliability of the Watch can be confirmed.
- If the Watch A is seen to consistently drift either faster or slower than the accurate time source,
    - then we can compensate for the drift by regularly adjusting the time on the Watch A.
    - e.g. every minute we could move the time on the Watch A second forward or 1 second backward.

Problem 3 Solution (b+)...

We can detect if the Watch A is wandering between too fast and too slow, by repeatedly comparing the Watch time to the accurate time source.











<hr>

### Synchronizing from a remote Clock Source<a name="Sync_Clock_Source"></a>

Definitions of terms..

WallClockTime: 


*  The term used to describe the universally agreed upon time.

SystemTime:


*  Similar to Wall Clock time.
*  It is maintained in software.
*  Initialised during boot up from the Real Time Clock.
*  Often kept in sync with WallClockTime with the aid of NTP.

#### Scenario 1... Using the time read from a Wristwatch to set Linux SystemTime

Definition of 

Let's say that we manually set the Linux system time using a value read from our Watch's time.

The steps would be:

1. Read time from Watch.
2. Type the "date" command and the "Watch's time" on the command prompt, and press enter.
3. Code is executed.
4. System Time is set.

The problem, there is a delay between step 1 and step 4.
Therefore both time lines (Watch's time and SystemTime will never be exactly in Sync.

WristWatch time  = 10

SystemTime       = 15

OffSet           = 05

Problem 1,  Offset between the time taken to read the Watch Time and set the SystemTime.
Problem 2,  No way to determine the accuracy of the Watch time, maybe the SystemTime was closer to the real time?






#### Scenario 2... Purchase an Accurate clock to use as a TimeLine reference

Problem 1,  Offset between the time taken to read the Accurate clock Time and set the SystemTime.
Problem 2,  Expensive, an accurate clock costs money.





#### Scenario 3... Use a shared Accurate clock as a TimeLine reference

Problem 1,  Delay between the time taken to read the shared Accurate clock Time and set the SystemTime.


#### Description of Problem 1...

Let's say that you have a friend working at a science laboratory who has access to a very accurate clock.
You could make a phone call to the friend and ask what the time is.

<PRE style="font-size: 60%">
 

   ____                                                        ____
  / 12 \                                                      / 12 \
 /      \                                                    /      \
( 9  +->3)                /+----------------+/              ( 9  +->3)
 \   \  /                /+----------------+/                \   \  /
  \__6_/          /~~~~~/                  /                  \__6_/
                 /     /+----------------+/+\
      ,'"".     /     /++---------------+/ | \           ,'"".
      )  ,+    /          |                |  \          )  ,+
     /  /,'+. /           |                |   \        /  /,'+.
    /  //  /.`.           |                |    \      /  //  /.`.
  ,'  //  /  `.`.         |                |     \   ,'  //  /  `.`.
 (    )++.`.   //+        |                |      \ (    )++.`.   //+
 +`++'+   `.`.// +        +                +       \+`++'+   `.`.// +
  `++'      `./  /                                   `++'      `./  /
    |         + /                                      |         + /
    +_________+/                                       +_________+/




</PRE>

There are many problems with this solution including the following...

1. The delay for the person on the other end to read the clock and to say the time.
2. The delay for the electrical signal to travel through the long distance phone line.
3. The delay between when you have heard the complete time and the time taken to set the time.


Assuming that the current time is read out when we press a button on the phone.

* How can we determine the Round Trip Delay between when we press the button on the phone and when we receive the voice recording of the time?

* How can we determine the delay between when the remote system receives our query and when it sends the response?












---------------------------------------------------------------------------------------------------------

###  NTP Client to NTP Server Polling Mechanism<a name="NTP_Polling"></a>


#### NTP Packet Format

<PRE style="font-size: 75%">
+--------------------------------------------+
| LI | VN | Mode | Stratum | Poll |Precision |
+--------------------------------------------+
|                 Root Delay                 |
+--------------------------------------------+
|              Root Dispersion               |
+--------------------------------------------+
|            Reference Identifier            |
+--------------------------------------------+
|                                            |
|            Reference TimeStamp             |
|                                            |
+--------------------------------------------+
|                                            |
|             Origin TimeStamp               |
|                                            |
+--------------------------------------------+
|                                            |
|            Recieve TimeStamp               |
|                                            |
+--------------------------------------------+
|                                            |
|            Transmit TimeStamp              |
|                                            |
+--------------------------------------------+
|                                            |
|         Optional Fields / Digest           |
|                                            |
+--------------------------------------------+
</PRE>


*   LI (Leap Indicator) 2-bits
*   VN (NTP Version Number) 3-bits
*   Mode (Work Mode) 3-bits code that indicates the work mode, can be set to either of these values:
    * 0 - reserved
    * 1 - symmetric active
    * 2 - symmetric passive
    * 3 - client
    * 4 - server
    * 5 - broadcast or multicast
    * 6 - NTP control message
    * 7 - reserved for private use.
*   Stratum (Statum Level) 8-bits. An integer ranging from 1 to 16. (Stratum 1 clock has the highest precision, and a stratum 16 clock is not synchronized and cannot be used as a reference clock.
*   Poll ( Poll Interval ) - 8-bits maximum interval between successive messages.
*   Precision (precision of the local clock) - 8-bit signed integer.
*   Root Delay - Roundtrip delay to the primary reference source.
*   Root Dispersion - The maximum error of the local clock relative to the primary reference source.
*   Reference Identifier - Identifier of the particular reference source.
*   Reference Timestamp - Local time at which the local clock was last set or corrected.
*   Originate Timestamp - Local time at which the request departed from the client for the service host.
*   Receive Timestamp - Local time at which the request arrived at the service host.
 *   Transmit Timestamp - Local time at which the reply departed from the service host for the client.
*   Authenticator - Authentication information.



#### How an NTP Client synchronises with an NTP server


Various delays and offsets need to be taken into consideration when an NTP client is determining the correct time.


* T1 the client timestamp on the request packet
* T2 the server timestamp upon arrival
* T3 the server timestamp on the departure of the reply packet
* T4 the client timestamp upon arrival



<PRE>
<style>
  #ascii-art-packet {
    font-family: monospace;
    white-space: pre;
    font-size: 75%;
  }
</style>

<div id="ascii-art-packet"></div>


<script>
const frames = [
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    | T1 |   |            |   | T1 |    | |
|    | T2 | <----------------<-| T2 | <--+ |
|    | T3 |   |            |   | T3 |      |
|    | T4 |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    |    |   |            |   |    |      |
|    |    | ------------------>|    | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <--+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   |    |      |
|    |    | ------------------>|    | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <--+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   |    |      |
|    |    | ->----->------>--->|    | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <--+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ->----->------>--->|    | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <--+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <--+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   |    |    | |
|    |    | <------------------|    | <<-+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   | T1 |    | |
|    |    | <------------------| T2 | <<-+ |
|    |    |   |            |   |    |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   | T1 |    | |
|    |    | <------------------| T2 | <--+ |
|    |    |   |            |   | T3 |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    |    |   |            |   | T1 |    | |
|    |    | <-----<-----<----<-| T2 | <--+ |
|    |    |   |            |   | T3 |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    | T1 |   |            |   | T1 |    | |
|    | T2 | <-----<-----<----<-| T2 | <--+ |
|    | T3 |   |            |   | T3 |      |
|    |    |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
  `,
  `
 NTP CLIENT                 NTP SERVER
+-------------+            +---------------+
|             |            |               |
|    +----+   |            |   +----+      |
|    | T1 |   |            |   | T1 |      |
|    |    | ------------------>| T2 | +--+ |
|    |    |   |            |   |    |    | |
|    |    |   |            |   |    |    | |
|    +----+   |            |   +----+    | |
|             |            |             | |
|             |            |             | |
|    +----+   |            |   +----+    | |
|    | T1 |   |            |   | T1 |    | |
|    | T2 | <----------------<-| T2 | <--+ |
|    | T3 |   |            |   | T3 |      |
|    | T4 |   |            |   |    |      |
|    +----+   |            |   +----+      |
|             |            |               |
+-------------+            +---------------+
 `
];

let currentFrameIndex = 0;
const asciiArtElement = document.getElementById("ascii-art-packet");

function renderFrame() {
  asciiArtElement.textContent = frames[currentFrameIndex];
  currentFrameIndex = (currentFrameIndex + 1) % frames.length;
}

// Initial render
renderFrame();

// Start animation at 2 frames per second (500ms delay)
setInterval(renderFrame, 1000);
</script>

</PRE>

##### Formulas for calculating the RTD and OffSet

<PRE style="font-size:75%">

    Round Trip Delay = (T4 - T1) - (T3 - T2)

    Clock OffSet = [(T2 - T1) + (T3 - T4)] / 2

</PRE>

#### 3 example calculations for RTD and OffSet.

<PRE style="font-size:65%">
--------------------------------------------

Example A
 TimeStamps... T1=0, T2=2, T3=12, and T4=14


    RTD  =  ( T4 + T1 ) + ( T3 + T2 )
            ( 14 + 0  ) | ( 12 +  2 )
            (    14   ) + (    10   )
                     _______          
                        4
                     ~~~~~~~      
        
 OffSet =  [( T2 + T1 ) + ( T3 + T4 )] /2
           [(  2 + 0  ) | ( 12 | 14 )] /2
           [(    2    ) + (    +2   )] /2
           [            0            ] /2
                     _______          
                        0         
                     ~~~~~~~            
              
              
 
--------------------------------------------

Example B
 TimeStamps... T1=0, T2=4, T3=6, and T4=10

   RTD  =   ( T4 + T1 ) + ( T3 + T2 )
            ( 10 + 0  ) | (  6 +  4 )
            (   10    ) + (    2    )
                     _______          
                        8
                     ~~~~~~~
 
 OffSet =  [( T2 + T1 ) + ( T3 + T4 )] /2
           [(  4 + 0  ) | (  6 | 10 )] /2
           [(    4    ) + (    +4   )] /2
           [            0            ] /2
                     _______          
                        0
                     ~~~~~~~

--------------------------------------------

Example C
 TimeStamps... T1=10, T2=2, T3=12, and T4=24

    RTD  =  ( T4 + T1 ) + ( T3 + T2 )
            ( 24 + 10 ) | ( 12 +  2 )
            (   14    ) + (   10    )
                     _______           
                        4
                     ~~~~~~~

 OffSet =  [( T2 + T1 ) + ( T3 + T4 )] /2
           [(  2 | 10 ) | ( 12 | 24 )] /2
           [(    +8   ) | (    +12  )] /2
           [            20          ] /2
                      _______           
                        10
                      ~~~~~~~ 

--------------------------------------------  

</PRE>

<style>
  .container {
    float: left;
    width: 50%;
  }
  .form-container {
    border: 2px solid #ccc;
    padding: 20px;
    margin-bottom: 20px;
  }
  .form-container h3 {
    margin-top: 0;
  }
  input[type="text"] {
    width: 100px;
  }
</style>

<h3>Round Trip Delay and Offset Calculator</h3>

<p>Enter the values for T1, T2, T3, and T4 (in the format hh:mm:ss):</p>
<div class="container">
  <div class="form-container">
    <h3>NTP Client</h3>
    <form id="clientForm">
      <label for="T1">T1:</label>
      <input type="text" id="T1" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" placeholder="hh:mm:ss"><br><br>

      <label for="T4">T4:</label>
      <input type="text" id="T4" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" placeholder="hh:mm:ss"><br><br>
    </form>
  </div>
</div>

<div class="container">
  <div class="form-container">
    <h3>NTP Server</h3>
    <form id="serverForm">
      <label for="T2">T2:</label>
      <input type="text" id="T2" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" placeholder="hh:mm:ss"><br><br>

      <label for="T3">T3:</label>
      <input type="text" id="T3" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" placeholder="hh:mm:ss"><br><br>
    </form>
  </div>
</div>

<button type="submit" onclick="calculate()">Calculate</button>

<div id="results"></div>

<script>
function calculate() {
  // Getting input values for ntp Client
  var T1 = document.getElementById("T1").value;
  var T4 = document.getElementById("T4").value;

  // Getting input values for ntp Server
  var T2 = document.getElementById("T2").value;
  var T3 = document.getElementById("T3").value;

  // Validation check for T3 being after T2
  if (timeToSeconds(T3) <= timeToSeconds(T2)) {
    alert("Time travel is not possible. Please ensure that T3 is after T2.");
    return;
  }

  // Calculating Round Trip Delay
  var roundTripDelay = (timeToSeconds(T4) - timeToSeconds(T1)) - (timeToSeconds(T3) - timeToSeconds(T2));

  // Calculating Clock Offset
  var clockOffset = ((timeToSeconds(T2) - timeToSeconds(T1)) + (timeToSeconds(T3) - timeToSeconds(T4))) / 2;

  // Displaying results
  var resultDiv = document.getElementById("results");

  // Validation check for roundTripDelay
  if (roundTripDelay <= 0) {
    alert("The timestamp for the NTP packet receive time is earlier than the send time. The local clock is unstable.");
    return;
  }

  resultDiv.innerHTML = "<h3>Results:</h3>" +
                        "<p>Round Trip Delay: " + roundTripDelay + " seconds</p>" +
                        "<p>Clock Offset: " + clockOffset + " seconds</p>";
}

function timeToSeconds(timeString) {
  var parts = timeString.split(":");
  return (+parts[0]) * 3600 + (+parts[1]) * 60 + (+parts[2]);
}
</script>



---------------------------------------------------------------------------------------------------------

###  Networks and NTP Precision and Accuracy<a name="NTP_precision"></a>
 
The precision and accuracy of system time achievable and maintainable by an NTP (Network Time Protocol) client depend significantly on the network infrastructure between the NTP client and the NTP servers.
*  In a Local Area Network (LAN), the accuracy of NTP synchronization can typically reach the order of 100 microseconds (us).

*  Within a Wide Area Network (WAN), the accuracy may decrease slightly, with synchronization achievable in the order of several tens of milliseconds.

*  Over the Internet, the accuracy of NTP synchronization depends heavily on many different factors. Typically, selecting NTP servers closer to the client location rather than those farther away results in more precise time synchronization.


However, it's important to note that accuracy in all these scenarios is significantly influenced by factors such as jitter and asymmetric network paths.


---------------------------------------------------------------------------------------------------------



###  Sources for this document: <a name="Sources"></a>

Intel CPU specifications and developer guides

* [Intel 64-ia-32-architectures-software-developer-vol-2a-manual.pdf]( http://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-vol-2a-manual.pdf )
* [Intel 64-ia-32-architectures-software-developer-manual-325462.pdf]( http://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-manual-325462.pdf )
* [Intel 64-ia-32-architectures-software-developer-vol-3b-part-2-manual.html]( http://www.intel.com.au/content/www/au/en/architecture-and-technology/64-ia-32-architectures-software-developer-vol-3b-part-2-manual.html )
* [Intel timestamp-counter-scaling-virtualization-white-paper.pdf]( http://www.intel.com/content/dam/www/public/us/en/documents/white-papers/timestamp-counter-scaling-virtualization-white-paper.pdf )
* [Intel xeon-e5-v2-spec-update.pdf]( http://www.intel.com/content/dam/www/public/us/en/documents/specification-updates/xeon-e5-v2-spec-update.pdf )

Linux Kernel and Linux Distribution documentation

* [https://www.kernel.org/doc/Documentation/virtual/kvm/timekeeping.txt]( https://www.kernel.org/doc/Documentation/virtual/kvm/timekeeping.txt )
* [https://access.redhat.com/solutions/18627]( h.ttps://access.redhat.com/solutions/18627 )
* [kb.vmware.com]( https://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=1006427 )
* [RedHat - Virtualization-KVM_guest_timing_management]( https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/5/html/Virtualization/chap-Virtualization-KVM_guest_timing_management.html )
* [https://bugzilla.redhat.com/show_bug.cgi?id=698842]( https://bugzilla.redhat.com/show_bug.cgi?id=698842 )
* [http://blog.cr0.org/2009/05/time-stamp-counter-disabling-oddities.html]( http://blog.cr0.org/2009/05/time-stamp-counter-disabling-oddities.html )
* [http://www.cs.virginia.edu/~evans/cs216/guides/x86.html]( http://www.cs.virginia.edu/~evans/cs216/guides/x86.html )
* [http://man7.org/linux/man-pages/man2/prctl.2.html]( http://man7.org/linux/man-pages/man2/prctl.2.html )
* [https://www.chromium.org/chromium-os/how-tos-and-troubleshooting/tsc-resynchronization]( https://www.chromium.org/chromium-os/how-tos-and-troubleshooting/tsc-resynchronization )
* [https://wiki.archlinux.org/index.php/CPU_frequency_scaling]( https://wiki.archlinux.org/index.php/CPU_frequency_scaling )
* [http://btorpey.github.io/blog/2014/02/18/clock-sources-in-linux/]( http://btorpey.github.io/blog/2014/02/18/clock-sources-in-linux/ )
* [https://lkml.org/lkml/2005/11/4/173]( https://lkml.org/lkml/2005/11/4/173 )
* [Manual page clock_gettime]


NTP (Official Documentation)

* [https://www.eecis.udel.edu/~mills/ntp/html/index.html]( https://www.eecis.udel.edu/~mills/ntp/html/index.html )
* [https://www.amazon.com/Computer-Network-Time-Synchronization-Protocol/dp/0849358051/](https://www.amazon.com/Computer-Network-Time-Synchronization-Protocol/dp/0849358051/)
* [https://www.amazon.com/Computer-Network-Time-Synchronization-Protocol/dp/1439814635/]( https://www.amazon.com/Computer-Network-Time-Synchronization-Protocol/dp/1439814635/)
* [http://what-if.xkcd.com/26/ Leap second (XKCD always counts as official)]( http://what-if.xkcd.com/26/)

Wikipedia links

* [Segals Law]( https://en.wikipedia.org/wiki/Segal%27s_law )
* [List_of_Intel_microprocessors]( https://en.wikipedia.org/wiki/List_of_Intel_microprocessors )
* [P5 microarchitecture]( https://en.wikipedia.org/wiki/P5_%28microarchitecture%29#P5 )
* [Intel SpeedStep]( https://en.wikipedia.org/wiki/SpeedStep )
* [Wall-clock_time]( https://en.wikipedia.org/wiki/Wall-clock_time )
* [Time_Stamp_Counter]( https://en.wikipedia.org/wiki/Time_Stamp_Counter )
* [Linux_kernel]( https://en.wikipedia.org/wiki/Linux_kernel )
* [Allan_variance]( https://en.wikipedia.org/wiki/Allan_variance )

ASCII Art

* [https://www.asciiart.eu/electronics/phones](https://www.asciiart.eu/electronics/phones)

Extra Info

* [Measuring Wander and Jitter]( http://cp.literature.agilent.com/litweb/pdf/5988-6254EN.pdf )


